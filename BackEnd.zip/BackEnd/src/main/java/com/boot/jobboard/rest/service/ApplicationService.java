package com.boot.jobboard.rest.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.boot.jobboard.rest.dvo.Application;
import com.boot.jobboard.rest.repo.ApplicationRepository;
import com.boot.jobboard.rest.repo.JobRepository;

@Service
public class ApplicationService {
//	@Autowired
//	private ApplicationRepository applicationRepo;
//	
//	public Application applyJob(Application application) {
//		return applicationRepo.save(application);
//	}
	
	@Autowired
    private JobRepository jobRepository;

    @Autowired
    private ApplicationRepository applicationRepository;

    public Application createApplication(Application application) {
        if (!jobRepository.existsById(application.getJobId())) {
            throw new IllegalArgumentException("Job ID does not exist: " + application.getJobId());
        }
        return applicationRepository.save(application);
    }
}
