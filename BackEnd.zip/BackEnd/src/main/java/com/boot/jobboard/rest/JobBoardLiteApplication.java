package com.boot.jobboard.rest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JobBoardLiteApplication {

	public static void main(String[] args) {
		SpringApplication.run(JobBoardLiteApplication.class, args);
	}

}
