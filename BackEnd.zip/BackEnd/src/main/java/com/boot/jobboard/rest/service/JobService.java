package com.boot.jobboard.rest.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.boot.jobboard.rest.dvo.Job;
import com.boot.jobboard.rest.repo.JobRepository;

@Service
public class JobService {

	@Autowired
	private JobRepository jobRepo;
	
	public List<Job> getAllJobs() {
        return jobRepo.findAll();
    }

    public List<Job> searchJobs(String keyword) {
        return jobRepo.findByTitleContainingIgnoreCase(keyword);
    }

    public Optional<Job> getJobById(Long id) {
        return jobRepo.findById(id);
    }
    
    public Job saveJob(Job job) {
        return jobRepo.save(job);
    }


}
