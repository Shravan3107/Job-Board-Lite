package com.boot.jobboard.rest.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
public class EmailService {

	@Autowired
    private JavaMailSender mailSender;

    public void sendApplicationConfirmation(String toEmail, String fullName) {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(toEmail);
        message.setSubject("Application Received");
        message.setText("Dear " + fullName + ",\n\n"
                + "Thank you for applying. We have received your application and will get back to you shortly.\n\n"
                + "Best regards,\nJob Board Lite Team");

        mailSender.send(message);
    }
}

