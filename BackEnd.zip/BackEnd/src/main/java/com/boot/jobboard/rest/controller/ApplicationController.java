package com.boot.jobboard.rest.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.boot.jobboard.rest.dvo.Application;
import com.boot.jobboard.rest.service.ApplicationService;
import com.boot.jobboard.rest.service.EmailService;


@RestController
@RequestMapping("/api/applications")
@CrossOrigin(origins ="*")
public class ApplicationController {

	@Autowired
	private ApplicationService applicationService;
	
	
	
//	@PostMapping
//    public ResponseEntity<String> applyJob(@RequestBody Application application) {
//        applicationService.applyJob(application);
//        return ResponseEntity.ok("Application submitted successfully.");
//    }
//	@PostMapping
//    public Application submitApplication(@RequestBody Application application) {
//        return applicationService.createApplication(application);
//    }
	@Autowired
    private EmailService emailService;

    @PostMapping
    public ResponseEntity<String> submitApplication(@RequestBody Application application) {
        Application savedApp = applicationService.createApplication(application);

        emailService.sendApplicationConfirmation(savedApp.getEmail(), savedApp.getFullName());

        return ResponseEntity.ok("Application submitted successfully and email sent.");
    }


 
}
