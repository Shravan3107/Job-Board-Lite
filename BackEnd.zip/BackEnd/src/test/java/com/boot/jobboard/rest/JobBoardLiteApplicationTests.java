package com.boot.jobboard.rest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JobBoardLiteApplicationTests {

	@Test
	void contextLoads() {
	}

}
