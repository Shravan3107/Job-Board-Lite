import axios from 'axios';

const API = axios.create({ baseURL: 'http://localhost:8081/api' });

export const fetchJobs = () => API.get('/jobs');
export const searchJobs = (keyword) => API.get(`/jobs/search?role=${keyword}`);
export const fetchJobById = (id) => API.get(`/jobs/${id}`);
export const submitApplication = (application) => API.post('/applications', application);
