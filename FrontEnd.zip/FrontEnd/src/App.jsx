
import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import Home from './pages/Home';
import JobPage from './pages/JobPage';
import Confirmation from './pages/Confirmation';

const App = () => (
  <Router>
    <nav className="navbar navbar-expand-lg navbar-dark bg-primary">
      <div className="container">
        <Link className="navbar-brand" to="/">Job Board Lite</Link>
      </div>
    </nav>
    <main className="container py-4">
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/jobs/:id" element={<JobPage />} />
        <Route path="/confirmation" element={<Confirmation />} />

      </Routes>
      <footer className="bg-light text-center py-3 mt-5 border-top">
        <small>&copy; {new Date().getFullYear()} Job Board Lite. All rights reserved.</small>
      </footer>

    </main>
  </Router>
);

export default App;
