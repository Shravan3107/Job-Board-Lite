import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { submitApplication } from '../api';

const ApplicationForm = ({ jobId }) => {
  const [formData, setFormData] = useState({ fullName: '', email: '' });
  const navigate = useNavigate();

  const handleChange = (e) => setFormData({ ...formData, [e.target.name]: e.target.value });

  const handleSubmit = (e) => {
    e.preventDefault();
    submitApplication({ ...formData, jobId }).then(() => {
      navigate('/confirmation'); // Redirect after successful submission
    });
  };

  return (
    <form onSubmit={handleSubmit} className="mt-3">
      <div className="mb-3">
        <label className="form-label fw-semibold">Full Name</label>
        <input
          className="form-control"
          name="fullName"
          value={formData.fullName}
          onChange={handleChange}
          required
        />
      </div>
      <div className="mb-3">
        <label className="form-label fw-semibold">Email</label>
        <input
          type="email"
          className="form-control"
          name="email"
          value={formData.email}
          onChange={handleChange}
          required
        />
      </div>
      <button type="submit" className="btn btn-success w-100">
        Submit Application
      </button>
    </form>
  );
};

export default ApplicationForm;
