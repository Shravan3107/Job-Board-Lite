import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { fetchJobById } from '../api';
import ApplicationForm from './ApplicationForm';

const JobDetails = () => {
  const { id } = useParams();
  const [job, setJob] = useState(null);

  useEffect(() => {
    fetchJobById(id).then(res => setJob(res.data));
  }, [id]);

  if (!job) return <p>Loading...</p>;

  return (
    <div className="card shadow-sm p-4" style={{ backgroundColor: '#fff7ed' }}>
      <h2 className="text-primary">{job.title}</h2>
      <p><strong>Company:</strong> {job.company}</p>
      <p><strong>Location:</strong> {job.location}</p>
      <p>{job.description}</p>
      {job.salaryRange && <p><strong>Salary:</strong> {job.salaryRange}</p>}

      <h5 className="mt-4">Required Skills</h5>
      <div className="d-flex flex-wrap gap-2 mb-3">
        {job.requiredSkills.map((skill, index) => (
          <span key={index} className="badge rounded-pill bg-light text-dark border border-secondary">
            {skill}
          </span>
        ))}
      </div>



      <ApplicationForm jobId={job.id} />
    </div>

  );
};

export default JobDetails;