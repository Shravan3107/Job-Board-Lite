
import React from 'react';
import { Link } from 'react-router-dom';

const JobCard = ({ job, index }) => {
  const backgroundColor = index % 2 === 0 ? '#edf6f9' : '#e6f4ea'; // Pale teal (#edf6f9) and light mint (#e6f4ea)

  return (
    <div
      className="card shadow-sm p-3 mb-4 rounded"
      style={{ width: '300px', backgroundColor }}
    >
      <div className="card-body text-center">
        <h5 className="card-title fw-bold">{job.title}</h5>
        <p className="card-text mb-1"><strong>Company:</strong> {job.company}</p>
        <p className="card-text mb-3"><strong>Location:</strong> {job.location}</p>
        <Link to={`/jobs/${job.id}`} className="btn btn-primary w-100">View Details</Link>
      </div>
    </div>
  );
};

export default JobCard;

