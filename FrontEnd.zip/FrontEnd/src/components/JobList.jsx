import React from 'react';
import JobCard from './JobCard';

const JobList = ({ jobs }) => (
  <div className="d-flex flex-wrap justify-content-center gap-4">
    {jobs.length ? jobs.map((job, index) => (
      <JobCard key={job.id} job={job} index={index} />
    )) : <p>No jobs found.</p>}
  </div>
);

export default JobList;
