import React, { useState } from 'react';

const JobSearch = ({ onSearch }) => {
  const [keyword, setKeyword] = useState('');

  return (
    <form onSubmit={e => { e.preventDefault(); onSearch(keyword); }} className="mb-3">
      <div className="input-group">
        <input type="text" className="form-control" placeholder="Search by role..." value={keyword} onChange={e => setKeyword(e.target.value)} />
        <button className="btn btn-primary px-4 py-2 fw-semibold shadow-sm" type="submit">
          🔍 Search
        </button>
      </div>
    </form>
  );
};

export default JobSearch;