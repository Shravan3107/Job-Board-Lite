import React from 'react';
import JobDetails from '../components/JobDetails';

const JobPage = () => <div className="container mt-5"><JobDetails /></div>;

export default JobPage;

