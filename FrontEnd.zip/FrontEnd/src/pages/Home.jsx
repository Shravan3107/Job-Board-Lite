import React, { useEffect, useState } from 'react';
import { fetchJobs, searchJobs } from '../api';
import JobSearch from '../components/JobSearch';
import JobList from '../components/JobList';

const Home = () => {
  const [jobs, setJobs] = useState([]);

  useEffect(() => {
    fetchJobs().then(res => setJobs(res.data));
  }, []);

  const handleSearch = (keyword) => {
    searchJobs(keyword).then(res => setJobs(res.data));
  };

  return (
    <div className="container mt-5">
      <h1 className="mb-4 text-center text-primary fw-bold">Welcome to Job Board Lite</h1>
      <p className="text-center mb-5">Search and apply for your dream job</p>
      <JobSearch onSearch={handleSearch} />
      <h2 className="mb-5 text-center">Available Job Listings</h2>

      <JobList jobs={jobs} />
    </div>
  );
};

export default Home;