import React from 'react';
import { Link } from 'react-router-dom';

const Confirmation = () => (
  <div className="container mt-5">
    <div className="alert alert-success">
      <h4 className="alert-heading">Application Submitted!</h4>
      <p>Thank you for applying. We will review your application and get back to you soon.</p>
      <hr />
      <Link to="/" className="btn btn-primary">Go back to Job Listings</Link>
    </div>
  </div>
);

export default Confirmation;
